import VideoFeed from "@/components/VideoFeed";

export default function Home() {
  return <VideoFeed />;
}
